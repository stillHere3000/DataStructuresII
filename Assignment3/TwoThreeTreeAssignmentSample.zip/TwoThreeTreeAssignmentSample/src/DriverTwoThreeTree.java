import java.util.Scanner;

public class DriverTwoThreeTree {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		TwoThreeTree<String> tttree = new TwoThreeTree<String>();
		//complete the rest as per the instruction
	}
}